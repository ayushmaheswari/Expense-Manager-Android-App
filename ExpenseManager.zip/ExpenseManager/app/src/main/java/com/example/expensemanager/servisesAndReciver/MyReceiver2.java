package com.example.expensemanager.servisesAndReciver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyReceiver2 extends BroadcastReceiver {

    // on recive method by default method of
    // BrodcastReciver class to be implemented
    // when recives any intent
    @Override
    public void onReceive(Context context, Intent intent) {
        // toast is pop when notification is click and
        // user successfully signup in and
        // send it to login page
        Toast.makeText(context, "Signup Successfully...", Toast.LENGTH_SHORT).show();
    }
}
