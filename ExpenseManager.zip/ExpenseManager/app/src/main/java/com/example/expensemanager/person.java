package com.example.expensemanager;

public class person {

    // initilize a variable for all the filed
    // like date time amount and image

    String amount;
    String tdate;
    String desc;
    String image;

    // constructor of ther person class to
    // hold the data for all the field

    public person(String amount, String tdate, String desc, String image) {
        this.amount = amount;
        this.tdate = tdate;
        this.desc = desc;
        this.image = image;
    }

    //getter method getAmount()

    public String getAmount() {
        return amount;
    }

    //getter method getTdate()

    public String getTdate() {
        return tdate;
    }

    //getter method getDesc()

    public String getDesc() {
        return desc;
    }

    //getter method getImage()

    public String getImage() {
        return image;
    }
}

