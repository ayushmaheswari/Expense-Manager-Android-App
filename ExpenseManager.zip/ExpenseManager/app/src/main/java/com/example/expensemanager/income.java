package com.example.expensemanager;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;

public class income extends AppCompatActivity {

    // variable declaration of id, amount, date
    String id;
    EditText mamount, mdesc;
    String amoun, desc;
    int amount;

    //onCreate Activity method to be invoke when activity is started
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_income);
        Intent i = getIntent();

        // link of ui to coding part
        //and id access from xml part

        id = i.getStringExtra("id");
        mamount = (EditText) findViewById(R.id.amount);
        mdesc = (EditText) findViewById(R.id.desc);
    }


    // incomeEntery method to send data to the database


    public void incomeEntry(View view) {
        amoun = mamount.getText().toString();
        desc = mdesc.getText().toString();
        desc = desc.replaceAll(" ","-");

        amount = Integer.parseInt(amoun);


        if (amoun.length() != 0 && desc.length() != 0) {
            Toast.makeText(this, "Sending Data...", Toast.LENGTH_SHORT).show();

            //call Async task class if all the
            // field are not empty and data is
            // able to send it to database

            new Connection().execute();


        } else {
            // toast popup for if any of the field is empty
            Toast.makeText(this, "Fill the both field above...", Toast.LENGTH_SHORT).show();
        }
    }

    //AsyncTask class to run long runnning backgroud process
    // for data retrival and or sending the data to the datbases

    class Connection extends AsyncTask<String, String, String> {


        @Override
        protected String doInBackground(String... strings) {
            String result;
            try {
                // php code to be trigger to send data to the databases
                String host = "http://sociofun1.000webhostapp.com/android/insertincome.php?id=" + id + "&amount=" + amount + "&desc=" + desc;
                //httpClient client class for handling http calls
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(host));
                HttpResponse response = client.execute(request);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuilder stringBuffer = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuffer.append(line);
                }
                reader.close();
                result = stringBuffer.toString();
            } catch (Exception e) {
                return "Exception Caught.";
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getApplicationContext(), "Data send...", Toast.LENGTH_SHORT).show();
            try {
                // data is send to database and activity is change by
                // intent and send user to the main account page where
                // the list of all the transition is present

                Thread.sleep(1000);
                Intent i = new Intent(getApplicationContext(),expensepage.class);
                i.putExtra("id",id);
                startActivity(i);
                // thread function so that data is change and
                // reflacte in another activity in one second

                Thread.sleep(1000);
                finish();

            } catch (InterruptedException e) {
                // for catching if by chances any exception is occur
                e.printStackTrace();
            }

        }
    }
}
