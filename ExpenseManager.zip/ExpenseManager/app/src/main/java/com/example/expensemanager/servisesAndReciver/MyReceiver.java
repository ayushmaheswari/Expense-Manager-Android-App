package com.example.expensemanager.servisesAndReciver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {

    // on recive method by default method of
    // BrodcastReciver class to be implemented
    // when recives any intent
    @Override
    public void onReceive(Context context, Intent intent) {
        // toast is pop when notification is click and
        // user entered in the accounting page
        Toast.makeText(context, "Login Successfully...", Toast.LENGTH_SHORT).show();
    }
}
