package com.example.expensemanager;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.example.expensemanager.servisesAndReciver.MyReceiver2;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;

public class fragment2 extends AppCompatActivity {

    EditText mname, mmobileNumber, mpassword, mconfirmPassword;
    String name, mobileNumber, password, confirmPassword;

    // notification chennel for making notification
    private static final String CHANNEL_ID = "primary_notification_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment2);

        // initialize all the ui component like editest

        mname = (EditText) findViewById(R.id.name);
        mmobileNumber = (EditText) findViewById(R.id.number);
        mpassword = (EditText) findViewById(R.id.password);
        mconfirmPassword = (EditText) findViewById(R.id.confirmpassword);
        mpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
        mconfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());



    }

    // notification function to genrate the notificaton
    private void addNotification1() {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this,CHANNEL_ID)
                        .setSmallIcon(R.drawable.logomain)
                        .setContentTitle("Signup sussessfully")
                        .setContentText("Welcome to the Expense manager");

        // Add as notification


        // pending inent for notification click handling
        Intent intent = new Intent(getApplicationContext(), MyReceiver2.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0, builder.build());

    }

    // change activity to login activity

    public void login(View view) {
        Intent in = new Intent(this, fragment.class);
        startActivity(in);
        finish();
    }


    // entrense method to move in main account
    // handling page when data is displaying
    public void SignupInto(View view) {

        name = mname.getText().toString();
        name = name.replace(" ","-");
        mobileNumber = mmobileNumber.getText().toString();
        password = mpassword.getText().toString();
        confirmPassword = mconfirmPassword.getText().toString();


        if (name.length() != 0 && mobileNumber.length() != 0 && password.length() != 0 && confirmPassword.length()!=0) {
            if (Long.parseLong(mobileNumber)%Long.parseLong(mobileNumber)==0 && mobileNumber.length()==10){
                if (password.equals(confirmPassword)) {
                    Toast.makeText(this, "Sending Data...", Toast.LENGTH_SHORT).show();

                    // run async task if all detail are feilde for long
                    //
                    // running background process like data send to databses
                    new Connection().execute();

                    //start notifiacation
                    addNotification1();
                    Log.i("fragment2", "login sussesful pass ok");
                    Intent in = new Intent(this, login2.class);
                    in.putExtra("number",mobileNumber);
                    in.putExtra("password",password);
                    startActivity(in);
                    finish();

                } else {
                    Toast.makeText(this, "Password not match with confirmation...", Toast.LENGTH_SHORT).show();
                }
            } else {

                Toast.makeText(this, "Enter valid Mobile Number...", Toast.LENGTH_SHORT).show();
            }

        } else {
            Toast.makeText(this, "please fill the above fields...", Toast.LENGTH_SHORT).show();
        }




    }


    class Connection extends AsyncTask<String, String, String> {


        @Override
        protected String doInBackground(String... strings) {
            String result;
            try {
                String host = "http://sociofun1.000webhostapp.com/android/insert.php?name=" + name + "&number=" + mobileNumber + "&password=" + password;
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(host));
                HttpResponse response = client.execute(request);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuilder stringBuffer = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuffer.append(line);
                }
                reader.close();
                result = stringBuffer.toString();
            } catch (Exception e) {
                return "Exception Caught.";
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(fragment2.this, "Data send...", Toast.LENGTH_SHORT).show();


        }
    }
}
