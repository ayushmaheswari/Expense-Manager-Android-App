package com.example.expensemanager;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdopter extends BaseAdapter {

    Context ct;
    ArrayList<person> al;

    // constructer of the MyAdopter class
    public MyAdopter(Context ct , ArrayList<person> al)
    {
        //initialize the context and listview
        this.ct = ct;
        this.al = al;
    }


    // Base adapter class abstract method to be override

    @Override
    public int getCount() {
        return al.size();
    }

    // Base adapter class abstract method to be override

    @Override
    public Object getItem(int position) {
        return al.get(position);
    }

    // Base adapter class abstract method to be override

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // Base adapter class abstract method to be override

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        // method of the person class
        person p = (person) getItem(position);
        Activity at  =(Activity) ct;

        // inflate the xml file name list
        View v1 = at.getLayoutInflater().inflate(R.layout.list,null,false);

        // initilize the component of ui for programming purpose
        TextView iv1 = v1.findViewById(R.id.image);
        TextView tv1 = v1.findViewById(R.id.amount);
        TextView tv2 = v1.findViewById(R.id.tdate);
        TextView tv3 = v1.findViewById(R.id.desc);


        // set the value in the ui component to be display
        // in the form of listview to the user
        iv1.setText(p.getImage());
        tv1.setText(p.getAmount());
        tv2.setText(p.getTdate());
        tv3.setText(p.getDesc());

        return v1;
    }
}