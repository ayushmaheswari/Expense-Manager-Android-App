package com.example.expensemanager;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;

public class expensepage extends AppCompatActivity {

//id to aunthenticate the user
    String id;
    //listview for inflate user data that come from database
    ListView listView;

    // custom adapter for making custom list view

    static MyAdopter mad;
    ArrayList<person> al;
    //variable initialization
    int credit,debit,sum;
    TextView balance;
    @Override

    //onCreate Activity method to invoke Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expensepage);
        credit=0;debit=0;sum=0;
        al = new ArrayList<>();
        listView = (ListView)findViewById(R.id.listview);
        balance = findViewById(R.id.balance);
        Intent i = getIntent();
        id = i.getStringExtra("id");

        //call Async task class if all the
        // field are not empty and data is
        // able to send it to database

        new Connection().execute();
        id = i.getStringExtra("id");
    }

    // option menu to to place sine out button in the toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    // if sign out is clicked then onOptionsItemSelected
    // is invoked and do further process
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.signout)
        {
            // dialog builder is pop up to confirm if user
            // really want to signout or the button is click accidently
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setIcon(R.drawable.log);
            builder.setTitle("Sign Out");
            builder.setMessage("Are you sure want to Sign Out");

            // if user cick "yes" then sign out then
            // delete data from shared prefrenses

            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    new user(expensepage.this).removeUser();
                    Intent i = new Intent(getApplicationContext(),fragment.class);
                    startActivity(i);
                    finish();
                }
            });

            //if user click no the destroy the dialog box
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            AlertDialog alertDialog = builder.create();
            //for showing the dialog alert box
            alertDialog.show();
        }
        return true;
    }

    // anotheer method invoke when user press back
    @Override
    public void onBackPressed() {
        finish();
    }

    // genrate pdf so that user can share his detail with anyone




    public void genratePdf(View view) {

    }







    // if user want to invoke a income page to do income entery

    public void income(View view) {
        Intent i = new Intent(getApplicationContext(),income.class);
        i.putExtra("id",id);
        startActivity(i);
        finish();
    }

    // if user want to invoke a expense page to do expense entery

    public void expense(View view) {
        Intent i = new Intent(getApplicationContext(),expense.class);
        i.putExtra("id",id);
        startActivity(i);
        finish();
    }

    //AsyncTask class to run long runnning backgroud process
      // for data retrival and or sending the data to the datbases
    class Connection extends AsyncTask<String, String, String> {


        @Override
        protected String doInBackground(String... strings) {
            String result;
            try {
                // php code to be trigger to send data to the databases
                String host = "http://sociofun1.000webhostapp.com/android/fatchrow.php?id=" + id;
                //httpClient client class for handling http calls
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(host));
                HttpResponse response = client.execute(request);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuilder stringBuffer = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuffer.append(line);
                }
                reader.close();
                result = stringBuffer.toString();
            } catch (Exception e) {
                return "Exception Caught.";
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            try {

                // fatch the json data and then inflate in the list view with user id

                JSONArray jsonArray = new JSONArray(result);
                for(int i=0;i<jsonArray.length();i++) {
                    JSONObject object = (JSONObject) jsonArray.get(i);
                    Log.i("one" ," firs123t");
                    String mode = object.getString("mode");
                    String tdate = object.getString("tdate");
                    String amount = object.getString("amount");
                    String desc = object.getString("description");
                    desc = desc.replaceAll("-"," ");

                    if(mode.equals("c"))
                    {

                        // for credit
                        Log.i("one" ," first");
                        person p = new person(amount,tdate,desc,"Cr");
                        al.add(p);
                        credit = credit+Integer.parseInt(amount);
                    }
                    else if(mode.equals("d"))
                    {
                        // for debit
                        Log.i("one" ," sec");
                        person p = new person(amount,tdate,desc,"Dr");
                        al.add(p);
                        debit = debit+Integer.parseInt(amount);
                    }
                    //log for debugging purpose
                    Log.i("one" ," third");

                    //set adapter withe the data in the listview
                    mad = new MyAdopter(expensepage.this,al);
                    //set adapter in the list view
                    listView.setAdapter(mad);
                }

                // do calculation and give the final balance
                // after checking for it's income and expenses
                sum = credit-debit;
                balance.setText("Balance -> "+sum);

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }
}
