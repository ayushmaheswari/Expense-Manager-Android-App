package com.example.expensemanager;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.example.expensemanager.servisesAndReciver.MyReceiver;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;


public class fragment extends AppCompatActivity {

    // variable declaration
    EditText mmobileNumber, mpassword;
    String mobileNumber, password;
    String name;
    int idt;
    boolean flage = false;
    // notification chennel for making notification
    private static final String CHANNEL_ID = "primary_notification_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
        mmobileNumber = (EditText) findViewById(R.id.number);
        mpassword = (EditText) findViewById(R.id.password);
        mpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());


    }


    // to change and move to signup activity
    public void signup(View view) {
        Intent in = new Intent(this, fragment2.class);
        startActivity(in);
        finish();
    }


    // entrense method to move in main account
    // handling page when data is displaying
    public void LoginInto(View view) {
        mobileNumber = mmobileNumber.getText().toString();
        password = mpassword.getText().toString();
        if(mobileNumber.length()==0 || password.length()==0)
        {
            Toast.makeText(this, "Fill both the field", Toast.LENGTH_SHORT).show();
        }
        else
        {
            new Connection().execute();
        }
    }


    // notification function to genrate the notificaton
    private void addNotification1() {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this,CHANNEL_ID)
                        .setSmallIcon(R.drawable.logomain)
                        .setContentTitle("Login sussessfully")
                        .setContentText("Welcome to the Expense manager");

        // Add as notification


        // pending intent for notificaton click handling
        Intent intent = new Intent(getApplicationContext(), MyReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0, builder.build());

    }

    //AsyncTask class to run long runnning backgroud process
    // for data retrival and or sending the data to the datbases
    class Connection extends AsyncTask<String, String, String> {


        @Override
        protected String doInBackground(String... strings) {
            String result;
            try {

                // php code to be trigger to send data to the databases
                String host = "http://sociofun1.000webhostapp.com/android/fatch.php?number=" + mobileNumber + "&password=" + password;
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(host));
                HttpResponse response = client.execute(request);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuilder stringBuffer = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuffer.append(line);
                }
                reader.close();
                result = stringBuffer.toString();
                flage = true;
            } catch (Exception e) {
                return "Exception Caught.";
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            if(result.length()==0 || flage == false)
            {
                Toast.makeText(fragment.this, "Enter valid number or password or check network connection", Toast.LENGTH_SHORT).show();

            }
            else
            {
                /*user user = new user(fragment.this);
                user.setId(result);*/

                // stored data in the shared prefrenses for content provider
                SharedPreferences sharedPreferences;
                sharedPreferences = getSharedPreferences("login_details",MODE_PRIVATE);
                sharedPreferences.edit().putString("id",result).commit();
                addNotification1();
                // data is send to database and activity is change by
                // intent and send user to the main account page where
                // the list of all the transition is present
                Intent i = new Intent(getApplicationContext(),expensepage.class);
                i.putExtra("id",result);
                startActivity(i);
                finish();
            }
        }
    }

}