package com.example.expensemanager;

import android.content.Context;
import android.content.SharedPreferences;

public class user {

    // shared prefrense to maintain the user
    // identity and use it as a maintain a sessions
     SharedPreferences sharedPreferences;

     // context initialization
     Context context;
    public user(Context context) {
        this.context = context;

        //save detail in the login_details.xml file
        // for retrivel the data in offline mode

        sharedPreferences = context.getSharedPreferences("login_details",context.MODE_PRIVATE);
    }

    // invoke this method for delete data of the
    // user and remove data from the shared prfrenses

    public void removeUser()
    {
        sharedPreferences.edit().clear().commit();
    }


}
