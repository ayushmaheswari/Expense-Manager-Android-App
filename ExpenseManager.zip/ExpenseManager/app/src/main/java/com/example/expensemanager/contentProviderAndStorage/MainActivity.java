package com.example.expensemanager.contentProviderAndStorage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.expensemanager.R;
import com.example.expensemanager.expensepage;
import com.example.expensemanager.fragment;

public class MainActivity extends AppCompatActivity {


    // oncreate activity method to invoke when activity started
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        // content provider shared preferences

        final SharedPreferences sharedPreferences;
        sharedPreferences = getSharedPreferences("login_details",MODE_PRIVATE);


        // handler for post delay so that user can wait and
        // see company logo for  1.5 sec
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (sharedPreferences.getString("id","")==""){

                    // intent send to login page if it not registered user

                    Intent i = new Intent(getApplicationContext(), fragment.class);
                    startActivity(i);
                    finish();
                }
                else
                {
                    // intent send to accounts page if is registered user
                    // to maintain sessions
                    Intent i = new Intent(getApplicationContext(), expensepage.class);
                    i.putExtra("id",sharedPreferences.getString("id",""));
                    startActivity(i);
                    finish();
                }

            }
        },1500);
    }


}
